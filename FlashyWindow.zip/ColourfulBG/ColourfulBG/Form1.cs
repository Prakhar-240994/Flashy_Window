﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ColourfulBG
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Goes from Green to Pink
            for (int c = 0; c <= 254; c++)
            {
                this.BackColor = Color.FromArgb(c,255-c,c);
                System.Threading.Thread.Sleep(10);
                Application.DoEvents();
            }

            // Goes back to Green from Pink
            for (int c = 254; c >= 0; c--)
            {
                this.BackColor = Color.FromArgb(c, 255 - c, c);
                System.Threading.Thread.Sleep(10);
                Application.DoEvents();
            }
        }
    }
}
